GAME APK project source — host/board device. Open in Android Studio, sync Gradle, build APK. This is source, not compiled APK.

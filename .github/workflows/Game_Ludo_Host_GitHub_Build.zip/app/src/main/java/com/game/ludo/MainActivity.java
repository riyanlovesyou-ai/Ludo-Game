package com.game.ludo;
import android.app.Activity;import android.os.Bundle;import android.webkit.*;import android.view.View;import android.widget.Toast;import java.net.*;import java.io.*;import java.util.concurrent.*;
public class MainActivity extends Activity{
 WebView w; ExecutorService pool=Executors.newCachedThreadPool(); ServerSocket server; Socket client; PrintWriter out;
 @Override public void onCreate(Bundle b){super.onCreate(b);w=new WebView(this);w.setBackgroundColor(0xffeef2f7);WebSettings s=w.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);w.setOverScrollMode(View.OVER_SCROLL_NEVER);w.addJavascriptInterface(new Bridge(),"Native");setContentView(w);w.loadUrl("file:///android_asset/index.html");}
 class Bridge{
  @JavascriptInterface public String localIp(){try{for(Enumeration<NetworkInterface> e=NetworkInterface.getNetworkInterfaces();e.hasMoreElements();){NetworkInterface n=e.nextElement();for(Enumeration<InetAddress>a=n.getInetAddresses();a.hasMoreElements();){InetAddress ip=a.nextElement();if(!ip.isLoopbackAddress()&&ip instanceof Inet4Address)return ip.getHostAddress();}}}catch(Exception ex){}return "IP unavailable";}
  @JavascriptInterface public void startHost(){pool.execute(()->{try{server=new ServerSocket(8765);sendJs("hostStatus('Hosting on port 8765. IP: '+Native.localIp())");while(!server.isClosed()){Socket s=server.accept();client=s;readSocket(s);}}catch(Exception e){sendJs("hostStatus('Host error: "+safe(e.getMessage())+"')");}});}
  @JavascriptInterface public void connect(String ip){pool.execute(()->{try{Socket s=new Socket();s.connect(new InetSocketAddress(ip,8765),6000);client=s;out=new PrintWriter(new OutputStreamWriter(s.getOutputStream()),true);sendJs("hostStatus('Connected to host '+"+quote(ip)+")");readSocket(s);}catch(Exception e){sendJs("hostStatus('Connection failed: "+safe(e.getMessage())+"')");}});}
  @JavascriptInterface public void send(String msg){try{if(client!=null&&client.isConnected()&&out!=null)out.println(msg);else if(client!=null&&client.isConnected()){out=new PrintWriter(new OutputStreamWriter(client.getOutputStream()),true);out.println(msg);}}catch(Exception e){}}
  void readSocket(Socket s){try{BufferedReader r=new BufferedReader(new InputStreamReader(s.getInputStream()));String line;while((line=r.readLine())!=null){final String m=line;sendJs("receiveRemote("+quote(m)+")");}}catch(Exception e){sendJs("hostStatus('Disconnected')");}}
  void sendJs(String js){runOnUiThread(()->w.evaluateJavascript(js,null));}
  String safe(String x){return x==null?"error":x.replace("'","").replace("\\","");}
  String quote(String x){return "'"+(x==null?"":x.replace("\\","\\\\").replace("'","\\'").replace("\n",""))+"'";}
 }
 @Override public void onDestroy(){try{if(server!=null)server.close();if(client!=null)client.close();}catch(Exception e){}pool.shutdownNow();super.onDestroy();}
}
